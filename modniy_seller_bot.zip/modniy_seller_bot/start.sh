#!/bin/bash
pip install -r requirements.txt
python modniy_seller_bot.py